
// 회원가입 모달창 js

// 회원가입 버튼에 클릭 이벤트리스너 추가
// : 첫화면이 아닌, 로그인 클릭하면 나오는 모달창에 있기 때문에 
document.addEventListener("click", function (e) {
    if (e.target.id == "div-jointxt") {
        showJoinModal();
    }
})


function showJoinModal() {
    // 회원가입 모달창 띄우기
    modal.style.display = "block";
    modalJoin.style.overflow = "hidden";
    // 로그인 모달창 없애기
    modalLogin.style.display = "none";
    // 회원가입 폼 띄우기
    modalJoin.style.display = "block";

    closejoin.addEventListener("click", function () {
        removeModal();
        console.log("닫혀라 얍");
    })
}

// 바깥 영역 클릭하면 닫히게
document.addEventListener("mouseup", function (e) {
    if (!modalLogin.contains(e.target) && !modalJoin.contains(e.target)) {
        removeModal();
    }
});
